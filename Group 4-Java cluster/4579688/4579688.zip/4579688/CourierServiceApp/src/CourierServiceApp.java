import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class CourierServiceApp {
    private static Connection connection;

    public static void main(String[] args) {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish a connection to the database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier_service", "root", "Akash123");

            Scanner scanner = new Scanner(System.in);
            parcelManagement parcelManagement = new parcelManagement(connection);
            customerManagement customerManagement = new customerManagement(connection);
            deliveryOperations deliveryOperations = new deliveryOperations(connection);

            while (true) {
                System.out.println("Courier Service Management System");
                System.out.println("1. Parcel Management");
                System.out.println("2. Customer Management");
                System.out.println("3. Delivery Operations");
                System.out.println("4. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        parcelManagement.displayMenu(scanner);
                        break;
                    case 2:
                        customerManagement.displayMenu(scanner);
                        break;
                    case 3:
                        deliveryOperations.displayMenu(scanner);
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        connection.close();
                        System.exit(0);
                    default:
                        System.out.println("Invalid option! Please try again.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
