import java.sql.*;
import java.util.Scanner;

public class customerManagement {
    private Connection connection;

    // Constructor to set the database connection
    public customerManagement(Connection connection) {
        this.connection = connection;
    }

    // Register a new customer
    public void addCustomer(Scanner scanner) {
        try {
            System.out.print("Enter Customer Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter Customer Email: ");
            String email = scanner.nextLine();
            System.out.print("Enter Customer Phone Number: ");
            String phoneNumber = scanner.nextLine();

            String query = "INSERT INTO Customer (customer_name, email, phone_number) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, phoneNumber);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Customer added successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error adding customer.");
        }
    }

    // View customer details
    public void viewCustomer(Scanner scanner) {
        try {
            System.out.print("Enter Customer ID to view: ");
            int customerId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            String query = "SELECT * FROM Customer WHERE customer_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, customerId);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Customer ID: " + resultSet.getInt("customer_id"));
                System.out.println("Name: " + resultSet.getString("customer_name"));
                System.out.println("Email: " + resultSet.getString("email"));
                System.out.println("Phone Number: " + resultSet.getString("phone_number"));
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error viewing customer.");
        }
    }

    // Update customer information
    public void updateCustomer(Scanner scanner) {
        try {
            System.out.print("Enter Customer ID to update: ");
            int customerId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            System.out.print("Enter new Customer Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new Customer Email: ");
            String email = scanner.nextLine();
            System.out.print("Enter new Customer Phone Number: ");
            String phoneNumber = scanner.nextLine();

            String query = "UPDATE Customer SET customer_name = ?, email = ?, phone_number = ? WHERE customer_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, phoneNumber);
            statement.setInt(4, customerId);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Customer updated successfully!");
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error updating customer.");
        }
    }

    // Delete a customer
    public void deleteCustomer(Scanner scanner) {
        try {
            System.out.print("Enter Customer ID to delete: ");
            int customerId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            String query = "DELETE FROM Customer WHERE customer_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, customerId);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Customer deleted successfully!");
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error deleting customer.");
        }
    }

    // Method to display the Customer Management menu
    public void displayMenu(Scanner scanner) {
        while (true) {
            System.out.println("\nCustomer Management Menu");
            System.out.println("1. Add Customer");
            System.out.println("2. View Customer");
            System.out.println("3. Update Customer");
            System.out.println("4. Delete Customer");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    addCustomer(scanner);
                    break;
                case 2:
                    viewCustomer(scanner);
                    break;
                case 3:
                    updateCustomer(scanner);
                    break;
                case 4:
                    deleteCustomer(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }
}
