import java.sql.*;
import java.util.Scanner;

public class deliveryOperations {
    private Connection connection;

    // Constructor to set the database connection
    public deliveryOperations(Connection connection) {
        this.connection = connection;
    }

    // Schedule a parcel delivery
    public void scheduleDelivery(Scanner scanner) {
        try {
            System.out.print("Enter Parcel ID: ");
            int parcelId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character
            System.out.print("Enter Customer ID: ");
            int customerId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character
            System.out.print("Enter Delivery Date (YYYY-MM-DD): ");
            String deliveryDate = scanner.nextLine();
            System.out.print("Enter Delivery Cost: ");
            double deliveryCost = scanner.nextDouble();
            scanner.nextLine(); // Consume the newline character

            String query = "INSERT INTO Delivery (parcel_id, customer_id, delivery_date, delivery_status, delivery_cost) VALUES (?, ?, ?, 'Scheduled', ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, parcelId);
            statement.setInt(2, customerId);
            statement.setString(3, deliveryDate);
            statement.setDouble(4, deliveryCost);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Delivery scheduled successfully!");
                updateParcelStatus(parcelId, "Scheduled"); // Update the parcel status
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error scheduling delivery.");
        }
    }

    // Update the status of a delivery
    public void updateDeliveryStatus(Scanner scanner) {
        try {
            System.out.print("Enter Delivery ID: ");
            int deliveryId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character
            System.out.print("Enter new Delivery Status (In Transit, Delivered): ");
            String newStatus = scanner.nextLine();

            String query = "UPDATE Delivery SET delivery_status = ? WHERE delivery_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, newStatus);
            statement.setInt(2, deliveryId);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Delivery status updated successfully!");
                updateParcelStatusFromDelivery(deliveryId, newStatus);
            } else {
                System.out.println("Delivery not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error updating delivery status.");
        }
    }

    // View delivery history
    public void viewDeliveryHistory(Scanner scanner) {
        try {
            System.out.print("Enter Customer ID to view delivery history: ");
            int customerId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            String query = "SELECT * FROM Delivery WHERE customer_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, customerId);

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                System.out.println("Delivery ID: " + resultSet.getInt("delivery_id"));
                System.out.println("Parcel ID: " + resultSet.getInt("parcel_id"));
                System.out.println("Delivery Date: " + resultSet.getString("delivery_date"));
                System.out.println("Delivery Status: " + resultSet.getString("delivery_status"));
                System.out.println("Delivery Cost: " + resultSet.getDouble("delivery_cost"));
                System.out.println("---------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error viewing delivery history.");
        }
    }

    // Calculate delivery cost
    public void calculateDeliveryCost(Scanner scanner) {
        try {
            System.out.print("Enter Parcel ID to calculate delivery cost: ");
            int parcelId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            String query = "SELECT delivery_cost FROM Delivery WHERE parcel_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, parcelId);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                double deliveryCost = resultSet.getDouble("delivery_cost");
                System.out.println("Delivery Cost: " + deliveryCost);
            } else {
                System.out.println("Parcel not found or no delivery scheduled for this parcel.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error calculating delivery cost.");
        }
    }

    // Update parcel status based on delivery status
    private void updateParcelStatusFromDelivery(int deliveryId, String newStatus) {
        try {
            // Find the associated parcel ID from the Delivery table
            String query = "SELECT parcel_id FROM Delivery WHERE delivery_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, deliveryId);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                int parcelId = resultSet.getInt("parcel_id");
                updateParcelStatus(parcelId, newStatus);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update the parcel status in the Parcel table
    private void updateParcelStatus(int parcelId, String newStatus) {
        try {
            String query = "UPDATE Parcel SET status = ? WHERE parcel_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, newStatus);
            statement.setInt(2, parcelId);

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to display the Delivery Operations menu
    public void displayMenu(Scanner scanner) {
        while (true) {
            System.out.println("\nDelivery Operations Menu");
            System.out.println("1. Schedule Delivery");
            System.out.println("2. Update Delivery Status");
            System.out.println("3. View Delivery History");
            System.out.println("4. Calculate Delivery Cost");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    scheduleDelivery(scanner);
                    break;
                case 2:
                    updateDeliveryStatus(scanner);
                    break;
                case 3:
                    viewDeliveryHistory(scanner);
                    break;
                case 4:
                    calculateDeliveryCost(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }
}
