import java.sql.*;
import java.util.Scanner;

public class parcelManagement {
    private Connection connection;

    // Constructor to set the database connection
    public parcelManagement(Connection connection) {
        this.connection = connection;
    }

    // Add a new parcel
    public void addParcel(Scanner scanner) {
        try {
            System.out.print("Enter Sender Name: ");
            String senderName = scanner.nextLine();
            System.out.print("Enter Sender Address: ");
            String senderAddress = scanner.nextLine();
            System.out.print("Enter Recipient Name: ");
            String recipientName = scanner.nextLine();
            System.out.print("Enter Recipient Address: ");
            String recipientAddress = scanner.nextLine();
            System.out.print("Enter Parcel Weight: ");
            double weight = scanner.nextDouble();
            scanner.nextLine(); // Consume the newline character

            String query = "INSERT INTO Parcel (sender_name, sender_address, recipient_name, recipient_address, weight, status) VALUES (?, ?, ?, ?, ?, 'Scheduled')";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, senderName);
            statement.setString(2, senderAddress);
            statement.setString(3, recipientName);
            statement.setString(4, recipientAddress);
            statement.setDouble(5, weight);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Parcel added successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error adding parcel.");
        }
    }

    // View parcel details
    public void viewParcel(Scanner scanner) {
        try {
            System.out.print("Enter Parcel ID to view: ");
            int parcelId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            String query = "SELECT * FROM Parcel WHERE parcel_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, parcelId);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Parcel ID: " + resultSet.getInt("parcel_id"));
                System.out.println("Sender Name: " + resultSet.getString("sender_name"));
                System.out.println("Sender Address: " + resultSet.getString("sender_address"));
                System.out.println("Recipient Name: " + resultSet.getString("recipient_name"));
                System.out.println("Recipient Address: " + resultSet.getString("recipient_address"));
                System.out.println("Weight: " + resultSet.getDouble("weight"));
                System.out.println("Status: " + resultSet.getString("status"));
            } else {
                System.out.println("Parcel not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error viewing parcel.");
        }
    }

    // Update parcel information
    public void updateParcel(Scanner scanner) {
        try {
            System.out.print("Enter Parcel ID to update: ");
            int parcelId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            System.out.print("Enter new Status (Scheduled, In Transit, Delivered): ");
            String status = scanner.nextLine();

            String query = "UPDATE Parcel SET status = ? WHERE parcel_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, status);
            statement.setInt(2, parcelId);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Parcel updated successfully!");
            } else {
                System.out.println("Parcel not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error updating parcel.");
        }
    }

    // Delete a parcel
    public void deleteParcel(Scanner scanner) {
        try {
            System.out.print("Enter Parcel ID to delete: ");
            int parcelId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            String query = "DELETE FROM Parcel WHERE parcel_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, parcelId);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Parcel deleted successfully!");
            } else {
                System.out.println("Parcel not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error deleting parcel.");
        }
    }

    // Method to display the Parcel Management menu
    public void displayMenu(Scanner scanner) {
        while (true) {
            System.out.println("\nParcel Management Menu");
            System.out.println("1. Add Parcel");
            System.out.println("2. View Parcel");
            System.out.println("3. Update Parcel");
            System.out.println("4. Delete Parcel");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    addParcel(scanner);
                    break;
                case 2:
                    viewParcel(scanner);
                    break;
                case 3:
                    updateParcel(scanner);
                    break;
                case 4:
                    deleteParcel(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }
}
