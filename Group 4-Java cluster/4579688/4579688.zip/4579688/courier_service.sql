CREATE DATABASE courier_service;

USE courier_service;

CREATE TABLE Customer (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100),
    email VARCHAR(100),
    phone_number VARCHAR(15)
);

CREATE TABLE Parcel (
    parcel_id INT AUTO_INCREMENT PRIMARY KEY,
    sender_name VARCHAR(100),
    sender_address TEXT,
    recipient_name VARCHAR(100),
    recipient_address TEXT,
    weight DECIMAL(10, 2),
    status ENUM('Scheduled', 'In Transit', 'Delivered')
);

CREATE TABLE Delivery (
    delivery_id INT AUTO_INCREMENT PRIMARY KEY,
    parcel_id INT,
    customer_id INT,
    delivery_date DATE,
    delivery_status ENUM('Scheduled', 'In Transit', 'Delivered'),
    delivery_cost DECIMAL(10, 2),
    FOREIGN KEY (parcel_id) REFERENCES Parcel(parcel_id),
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);
